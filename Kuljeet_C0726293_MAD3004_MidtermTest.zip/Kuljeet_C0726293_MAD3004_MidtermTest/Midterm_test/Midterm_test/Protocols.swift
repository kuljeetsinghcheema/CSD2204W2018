//
//  Protocols.swift
//  Midterm_test
//
//  Created by Kuljeet Singh on 2018-02-07.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

protocol sportDisplay {
    func screen()
}
