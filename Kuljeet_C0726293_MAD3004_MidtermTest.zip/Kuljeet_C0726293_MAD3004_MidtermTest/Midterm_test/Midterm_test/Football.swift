//
//  Football.swift
//  Midterm_test
//
//  Created by Kuljeet Singh on 2018-02-07.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class football: sports{
    var minutes: Int?
    var minutesPlayed: Int?
    var goalsScored: Int?
    var redCardsIssued: Int?
    var peneltyTime: Int?
    var peneltyGoals: Int?
    var totalGoals: Int?
    
    override init() {
        super.init()
        self.minutes = 0
        self.minutesPlayed = 0
        self.goalsScored = 0
        self.redCardsIssued = 0
        self.peneltyTime = 0
        self.peneltyGoals = 0
        self.totalGoals = 0
    }
    
    init(sType: String, pCount: Int, min: Int, minPlayed: Int, gScored: Int, rCardIssued: Int, pTime: Int, pGoals: Int, totGoals: Int)
    {
        super.init(sType: sType, pCount: pCount)
        self.minutes = min
        self.minutesPlayed = minPlayed
        self.goalsScored = gScored
        self.redCardsIssued = rCardIssued
        self.peneltyTime = pTime
        self.peneltyGoals = pGoals
        self.totalGoals = totGoals
    }
    
    override func display()
    {
        super.display()
        print("minutes played : ",self.minutesPlayed!)
        print("total minutes : ",self.minutes!)
        print("Goals Scored:", self.goalsScored!)
        print("Red Cards issued:", self.redCardsIssued!)
        print("Total Penelty Time:", self.peneltyTime!)
        print("Total Penelty Goals:", self.peneltyGoals!)
    }
    func tgoals()
    {
       var gTotal = self.totalGoals
       let penGoals = self.peneltyGoals
       let scorGoals = self.goalsScored
        
        gTotal = penGoals! + scorGoals!
        print("total goals scored:", gTotal!)
    }
}

