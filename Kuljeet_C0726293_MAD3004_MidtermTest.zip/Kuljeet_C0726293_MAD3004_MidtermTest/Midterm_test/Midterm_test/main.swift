//
//  main.swift
//  Midterm_test
//
//  Created by Kuljeet Singh on 2018-02-07.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

var Sport = sports(sType: "Indoor",pCount: 10)
Sport.display()

var cricketmatch1 = cricket(sType: "Indoor", pCount: 11, format: "test match", oCount: 200, wDown: 10, rScored: 400, oPlayed: 200, avgRRate: 3)
cricketmatch1.display()

var cricketmatch2 = cricket(sType: "Outdoor", pCount: 12, format: "one day", oCount: 50, wDown: 8, rScored: 250, oPlayed: 50, avgRRate: 6)
cricketmatch2.display()

var footballmatch1 = football(sType: "outdoor", pCount: 8, min: 40, minPlayed: 40, gScored: 10, rCardIssued: 0, pTime: 2, pGoals: 1, totGoals: 11)
footballmatch1.display()
var footballmatch2 = football(sType: "indoor", pCount: 10, min: 50, minPlayed: 48, gScored: 12, rCardIssued: 1, pTime: 4, pGoals: 3, totGoals: 15)
var screenply = sports(sType: "outdoor", pCount: 13)
screenply.screen()
