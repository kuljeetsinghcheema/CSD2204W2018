//
//  Cricket.swift
//  Midterm_test
//
//  Created by Kuljeet Singh on 2018-02-07.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class cricket: sports
{
    var mFormat: String?
    var oversCount: Int?
    var wicketsDown: Int?
    var runsScored: Int?
    var oversPlayed: Int?
    var avgRunRate: Int?
    
    override init() {
        super.init()
        self.mFormat = ""
        self.oversCount = 6
        self.wicketsDown = 0
        self.runsScored = 0
        self.oversPlayed = 0
        self.avgRunRate = 0
    }
    
    init(sType: String, pCount: Int, format: String, oCount: Int, wDown:Int, rScored: Int, oPlayed: Int, avgRRate: Int)
    {
        super.init(sType: sType, pCount: pCount)
        self.mFormat = format
        self.oversCount = oCount
        self.wicketsDown = wDown
        self.runsScored = rScored
        self.oversPlayed = oPlayed
        self.avgRunRate = avgRRate
    }
    
    override func display(){
        super.display()
        print("sType : ",self.sportsType!)
        print("pCount : ",self.playersCount!)
        print("format:", self.mFormat!)
        print("oversCount:", self.oversCount!)
        print("runsScored:", self.runsScored!)
        print("oversPlayed:", self.oversPlayed!)
    }
    func avgRate()
    {
        let totalOvers = self.oversPlayed
        let totalRuns = self.runsScored
        var _ = self.avgRunRate!
        _ = totalRuns! / totalOvers!
        print("avg Run Rate:", self.avgRate)
        
    }
}
