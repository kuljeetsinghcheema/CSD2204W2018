//
//  Sports.swift
//  Midterm_test
//
//  Created by Kuljeet Singh on 2018-02-07.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation


class sports: sportDisplay{
    var sportsType : String?
    var playersCount : Int?

init(){
    self.sportsType = ""
    self.playersCount = 0
}

init(sType: String, pCount: Int)
{
    self.sportsType = sType
    self.playersCount = pCount
}

func display(){
    print("sportsType : ",self.sportsType!)
    print("playersCount : ",self.playersCount!)
    }
    func screen() {
        print("sports")
    }
}
